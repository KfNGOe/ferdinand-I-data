### docx2tei conversion by xslt from Wang with:<br>
..\github\ferdinand-I-data\src\docx2tei\docx\from\docxtotei.xsl 