### tei2dtabf conversion by xquery with:<br>
..\github\ferdinand-I-data\src\tei2dtabf\xquery\TeiToDtaBf.xquery

### and validation by rng-schema with (low priority): <br> 
..\github\ferdinand-I-data\src\tei2dtabf\schema\basisformat_all_ferdinand.rng 